n=int(input("Digite um número: "))

if (n%2):
	print('ímpar')
else:
	 print('par')