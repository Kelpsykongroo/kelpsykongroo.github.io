n=int(input('Digite um número'))
if(n%3):
	print(n)
else:
	print('Fizz')