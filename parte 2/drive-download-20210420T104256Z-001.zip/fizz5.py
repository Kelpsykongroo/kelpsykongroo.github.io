n=int(input('Digite um número: '))
if(n%5):
	print(n)
else:
	print('Fizz')