a=int(input('Digite um número: '))
b=int(input('Digite um número: '))
c=int(input('Digite um número: '))

delta=b**2 - 4*a*c

if(delta==0):
	r=(-b + delta**(1/2))/(2*a)
	print('a raiz desta equaç˜ao ´e', r)
else:
	if(delta<0):
		print("esta equacao nao possui raizes reais")
	else:
		r1=(-b + delta**(1/2))/(2*a)
		r2=(-b - delta**(1/2))/(2*a)
		if(r2>r1):
			print('as raizes da equacao sao', r1,'e', r2)
		else:
			print('as raizes da equacao sao', r2,'e', r1)