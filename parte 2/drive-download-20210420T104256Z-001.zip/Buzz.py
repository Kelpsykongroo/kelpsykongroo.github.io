n=int(input('Digite um número: '))
if(n%3 and n%5):
	print(n)
else:
	print('FizzBuzz')