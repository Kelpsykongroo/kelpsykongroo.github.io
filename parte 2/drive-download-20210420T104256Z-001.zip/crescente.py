n1=int(input('Digite um número: '))
n2=int(input('Digite um número: '))
n3=int(input('Digite um número: '))

if(n3>n2 and n2>n1):
	print("crescente")
else:
	print('não está em ordem crescente')